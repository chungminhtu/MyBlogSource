create table antiddos_product
(
  id              bigint       not null,
  product_id      bigint       not null,
  status          smallint(6)  not null,
  vas_code        varchar(255) null,
  promotion_code  varchar(255) null,
  phone_number    varchar(255) null,
  email           varchar(255) null,
  effect_datetime datetime     null,
  expire_datetime datetime     null,
  register_date   datetime     null,
  create_user     varchar(255) null,
  create_datetime datetime     null,
  update_user     varchar(255) null,
  update_datetime datetime     null,
  constraint antiddos_product_id_uindex
    unique (id)
);

alter table antiddos_product
  add primary key (id);

create table basic_fixed_line_product
(
  id                 bigint       not null,
  product_id         bigint       not null,
  isdn               varchar(255) null,
  account            varchar(255) null,
  password           varchar(50)  null,
  is_new             varchar(10)  null,
  first_connect      smallint(6)  null,
  status             smallint(6)  not null,
  create_user        int(10)      null,
  create_datetime    datetime     null,
  update_user        int(10)      null,
  update_datetime    datetime     null,
  telecom_service_id smallint(6)  null,
  constraint basic_fixed_line_product_id_uindex
    unique (id)
);

alter table basic_fixed_line_product
  add primary key (id);

create table email_product
(
  email_product_id bigint       not null,
  product_id       bigint       not null,
  email            varchar(255) null,
  password         varchar(255) null,
  effect_datetime  datetime     null,
  expire_datetime  datetime     null,
  status           smallint(6)  not null,
  create_user      varchar(255) null,
  create_datetime  datetime     null,
  update_user      varchar(255) null,
  update_datetime  datetime     null,
  constraint email_product_email_product_id_uindex
    unique (email_product_id)
);

alter table email_product
  add primary key (email_product_id);

create table goods_product
(
  id                        bigint       not null,
  product_id                bigint       not null,
  product_offering_id       bigint       not null,
  goods_type                varchar(100) null,
  quantity                  int(10)      null,
  serial                    varchar(100) null,
  imei                      varchar(100) null,
  lock_status               smallint(6)  null,
  status                    smallint(6)  not null,
  create_user               varchar(255) null,
  create_datetime           datetime     null,
  update_user               varchar(255) null,
  update_datetime           datetime     null,
  constraint goods_product_id_uindex
    unique (id)
);

alter table goods_product
  add primary key (id);

create table `group`
(
  group_id        bigint        not null,
  group_type      varchar(255)  not null,
  group_code      varchar(255)  not null,
  name            varchar(255)  null,
  status          smallint(6)   not null,
  description     varchar(2000) null,
  start_datetime  datetime      null,
  end_datetime    datetime      null,
  create_user     varchar(255)  null,
  create_datetime datetime      null,
  update_user     varchar(255)  null,
  update_datetime datetime      null,
  constraint group_group_id_uindex
    unique (group_id)
);

alter table `group`
  add primary key (group_id);

create table group_line_att
(
  group_line_att_id bigint       not null,
  group_id          bigint       not null,
  ext_key           varchar(255) not null,
  ext_value         varchar(255) null,
  new_ext_value     varchar(255) null,
  status            smallint(6)  not null,
  create_user       varchar(255) null,
  create_datetime   datetime     null,
  update_user       varchar(255) null,
  update_datetime   datetime     null,
  constraint group_line_att_group_line_att_id_uindex
    unique (group_line_att_id)
);

alter table group_line_att
  add primary key (group_line_att_id);

create table group_member
(
  group_member_id bigint       not null,
  group_id        bigint       not null,
  product_id      bigint       not null,
  status          smallint(6)  not null,
  start_datetime  datetime     null,
  end_datetime    datetime     null,
  create_user     varchar(255) null,
  create_datetime datetime     null,
  update_user     varchar(255) null,
  update_datetime datetime     null,
  constraint group_member_group_member_id_uindex
    unique (group_member_id)
);

alter table group_member
  add primary key (group_member_id);

create table group_type
(
  group_type           varchar(255)  null,
  name                 varchar(255)  null,
  min_member           bigint        null,
  max_member           bigint        null,
  max_discount_product bigint        null,
  product_offer_id     bigint        null,
  status               smallint(6)   null,
  description          varchar(2000) null,
  create_user          varchar(255)  null,
  create_datetime      datetime      null,
  update_user          varchar(255)  null,
  update_datetime      datetime      null,
  constraint group_type_group_type_uindex
    unique (group_type)
);

create table infrastructure
(
  infrastructure_id bigint        not null,
  product_id        bigint        not null,
  action_code       varchar(50)   not null,
  technology        smallint(6)   null,
  cable_box_id      bigint        null,
  team_code         varchar(50)   null,
  cable_box_code    varchar(100)  null,
  station_code      varchar(100)  null,
  cable_box_type    varchar(50)   null,
  vendor            varchar(50)   null,
  status            smallint(6)   not null,
  description       varchar(2000) null,
  create_user       varchar(255)  null,
  create_datetime   datetime      null,
  update_user       varchar(255)  null,
  update_datetime   datetime      null,
  constraint infrastructure_infrastructure_id_uindex
    unique (infrastructure_id)
);

alter table infrastructure
  add primary key (infrastructure_id);

create table place
(
  place_id         bigint        not null,
  product_id       bigint        not null,
  full_address     varchar(255)  null,
  input_address    varchar(255)  null,
  selected_address varchar(1000) null,
  address_code     varchar(500)  null,
  start_datetime   datetime      null,
  end_datetime     datetime      null,
  status           smallint(6)   not null,
  create_user      varchar(255)  null,
  create_datetime  datetime      null,
  update_user      varchar(255)  null,
  update_datetime  datetime      null,
  constraint place_place_id_uindex
    unique (place_id)
);

alter table place
  add primary key (place_id);

create table product
(
  product_id          bigint       not null,
  status              smallint(6)  not null,
  name                varchar(255) null,
  product_offering_id bigint       null,
  customer_id         bigint       null,
  start_datetime      datetime     null,
  end_datetime        datetime     null,
  shop_id             int(10)      null,
  staff_id            int(10)      null,
  reason_id           int(10)      null,
  create_user         varchar(255) null,
  create_datetime     datetime     null,
  update_user         varchar(255) null,
  update_datetime     datetime     null,
  constraint product_product_id_uindex
    unique (product_id)
);

alter table product
  add primary key (product_id);

create table product_activation
(
  product_active_id int(10)      not null,
  product_id        int(10)      not null,
  status            smallint(6)  not null,
  act_status        varchar(3)   null,
  start_datetime    datetime     null,
  end_datetime      datetime     null,
  create_user       varchar(255) null,
  create_datetime   datetime     null,
  update_user       varchar(255) null,
  update_datetime   datetime     null,
  constraint product_activation_product_active_id_uindex
    unique (product_active_id)
);

alter table product_activation
  add primary key (product_active_id);

create table product_change_queue
(
  product_change_queue_id bigint        not null,
  product_id              bigint        not null,
  action_code             varchar(10)   not null,
  product_code            varchar(50)   null,
  promotion_code          varchar(50)   null,
  ip_static               varchar(100)  null,
  effect_datetime         datetime      null,
  process_datetime        datetime      null,
  message_process         varchar(2000) null,
  attempt                 smallint(6)   null,
  status                  smallint(6)   null,
  create_user             varchar(255)  null,
  create_datetime         datetime      null,
  update_user             varchar(255)  null,
  update_datetime         datetime      null,
  constraint product_change_queue_product_change_queue_id_uindex
    unique (product_change_queue_id)
);

alter table product_change_queue
  add primary key (product_change_queue_id);

create table product_deposit
(
  product_deposit_id bigint       not null,
  product_id         bigint       not null,
  status             smallint(6)  not null,
  deposit            bigint       null,
  deposit_type       smallint(6)  null,
  start_time         datetime     null,
  end_time           datetime     null,
  user_ip            varchar(255) null,
  create_user        varchar(255) null,
  create_datetime    datetime     null,
  update_user        varchar(255) null,
  update_datetime    datetime     null,
  constraint product_deposit_product_deposit_id_uindex
    unique (product_deposit_id)
);

create table product_ip
(
  product_ip_id     int(10)      not null,
  product_id        int(10)      not null,
  ip                varchar(64)  null,
  ip_block          varchar(100) null,
  framed_ip_netmask varchar(100) null,
  ip_block_process  varchar(100) null,
  auto_assigned     smallint(6)  null,
  status_rating     smallint(6)  null,
  status            smallint(6)  not null,
  start_datetime    datetime     null,
  end_datetime      datetime     null,
  create_user       varchar(255) null,
  create_datetime   datetime     null,
  update_user       varchar(255) null,
  update_datetime   datetime     null,
  constraint product_ip_product_ip_id_uindex
    unique (product_ip_id)
);

alter table product_ip
  add primary key (product_ip_id);

create table product_limit_usage
(
  product_limit_usage_id int(10)       not null,
  product_id             int(10)       not null,
  status                 smallint(6)   not null,
  usage_limit            int(10)       null,
  file_name              varchar(1000) null,
  file_url               varchar(1000) null,
  start_datetime         datetime      null,
  end_datetime           datetime      null,
  create_user            varchar(255)  null,
  create_datetime        datetime      null,
  update_user            varchar(255)  null,
  update_datetime        datetime      null,
  constraint product_limit_usage_product_limit_usage_id_uindex
    unique (product_limit_usage_id)
);

alter table product_limit_usage
  add primary key (product_limit_usage_id);

create table product_offer
(
  product_offer_id          int(10)      not null,
  product_id                int(10)      not null,
  status                    smallint(6)  not null,
  product_offering_id       varchar(255) null,
  start_datetime            datetime     null,
  end_datetime              datetime     null,
  create_user               varchar(255) null,
  create_datetime           datetime     null,
  update_user               varchar(255) null,
  update_datetime           datetime     null,
  constraint product_offer_product_offer_id_uindex
    unique (product_offer_id)
);

alter table product_offer
  add primary key (product_offer_id);

create table product_promotion
(
  product_promotion_id int(10)      not null,
  product_id           int(10)      not null,
  status               smallint(6)  not null,
  promotion_code       varchar(255) null,
  start_datetime       datetime     null,
  end_datetime         datetime     null,
  expire_datetime      datetime     null,
  create_datetime      datetime     null,
  update_user          varchar(255) null,
  update_datetime      datetime     null,
  create_user          varchar(255) null,
  constraint product_promotion_product_promotion_id_uindex
    unique (product_promotion_id)
);

alter table product_promotion
  add primary key (product_promotion_id);

create table safenet_product
(
  id              bigint       not null,
  product_id      bigint       not null,
  status          smallint(6)  not null,
  code            varchar(255) null,
  promotion_code  varchar(255) null,
  phone_number    varchar(255) null,
  start_datetime  datetime     null,
  end_datetime    datetime     null,
  register_date   datetime     null,
  create_user     varchar(255) null,
  create_datetime datetime     null,
  update_user     varchar(255) null,
  update_datetime datetime     null,
  constraint safenet_product_id_uindex
    unique (id)
);

alter table safenet_product
  add primary key (id);

create table vas_product
(
  id              bigint       not null,
  product_id      bigint       not null,
  code            varchar(50)  not null,
  is_connected    int(10)      null,
  start_datetime  datetime     null,
  end_datetime    datetime     null,
  status          smallint(6)  not null,
  create_user     varchar(255) null,
  create_datetime datetime     null,
  update_user     varchar(255) null,
  update_datetime datetime     null,
  constraint vas_product_id_uindex
    unique (id)
);

alter table vas_product
  add primary key (id);

create table option_set
(
  id bigint not null primary key,
  code varchar(256) not null,
  name varchar(500) null,
  status varchar(2) not null,
  create_user varchar(50) not null,
  create_datetime datetime not null,
  update_user varchar(50) not null,
  update_datetime datetime not null,
  description varchar(512) null
) charset=utf8;

create index opset_code_idx
  on option_set (code);

create table option_set_value
(
  id bigint not null
    primary key,
  option_set_id bigint not null,
  name varchar(500) not null,
  value varchar(4000) not null,
  status varchar(1) not null,
  description varchar(512) null,
  create_user varchar(50) not null,
  create_datetime datetime not null,
  update_user varchar(50) not null,
  update_datetime datetime not null,
  display_order bigint null
);

create index opsetval_opset_idx
  on option_set_value (option_set_id);
